// main.js
// This file is only for general Home page behaviour.
// Donation logic lives in donate.js, find.js and sdg.js.

// Nothing special needed on the Home page right now.
// This file is kept here so the project structure matches
// the plan (one JS file per HTML page).
