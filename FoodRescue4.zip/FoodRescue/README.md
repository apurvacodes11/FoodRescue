# FoodRescue

FoodRescue is a simple web application that connects surplus food with
people who need it. It was built as a college micro-project.

## Project Description

Large amounts of edible food are wasted every day, while many people do
not have reliable access to food. FoodRescue lets people:

- Donate surplus food
- View available food donations
- Search for food by name, category or location
- Request available food
- Learn about food insecurity and food waste
- View food-security data from an international public data source

## Technologies Used

- HTML5
- CSS3
- JavaScript (DOM manipulation, localStorage, Fetch API, async/await)
- Bootstrap 5 (navbar, cards, forms, alerts, responsive grid)
- Chart.js (data visualization)

## Features

- **Home** — introduces the platform and the problem it addresses
- **Donate Food** — a form to list a surplus food donation, saved to `localStorage`
- **Find Food** — search and browse donations, and request a food item
- **SDG & Impact** — explains SDG 2 and SDG 12, shows live food-security
  data from an external API, and shows our own project impact numbers

## SDGs Addressed

- **SDG 2 — Zero Hunger**
- **SDG 12 — Responsible Consumption and Production**

## API Used

**World Bank Open Data API** — indicator `SN.ITK.DEFC.ZS`
("Prevalence of undernourishment, % of population"), which is FAO-sourced
data and directly matches the food-security theme of this project.

Example request used in the project:

```
https://api.worldbank.org/v2/country/IND;USA;BRA;NGA;CHN;ZAF;BGD;KEN/indicator/SN.ITK.DEFC.ZS?format=json&mrv=1&per_page=50
```

This API requires no key and no authentication, and returns plain JSON,
which keeps the code at a beginner level (`fetch()` + `async/await`).

**Note on FAOSTAT:** we originally considered calling the FAOSTAT API
directly, but its current developer portal requires a registered account
and a short-lived JWT token, and its legacy endpoint needs domain/item/
element codes that add unnecessary complexity for this project. The
World Bank API above returns the same underlying FAO food-security data
without any of that extra setup, so it was used instead.

## How to Run the Project

1. Download or clone this folder.
2. Open `index.html` in any web browser (double-click the file, or use
   a tool like VS Code's "Live Server" extension).
3. No installation or build step is required — everything runs in the
   browser using plain HTML, CSS and JavaScript.

## Uploading to GitHub

```
git init
git add .
git commit -m "Initial project"
git branch -M main
git remote add origin YOUR_REPOSITORY_URL
git push -u origin main
```
